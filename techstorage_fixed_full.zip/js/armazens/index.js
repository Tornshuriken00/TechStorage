// Obtém o corpo da tabela onde as linhas serão inseridas
const tbody = document.querySelector('#table tbody');

// Faz a requisição para buscar a lista de armazéns
fetch('../php/armazens/get_all.php')
    .then(response => response.json())
    .then(data => {
        const messageElement = document.getElementById('msg');
        
        // 1. Verifica o sucesso da requisição PHP
        if (!data.success) {
            messageElement.textContent = data.message || 'Erro';
            return;
        }

        // Limpa qualquer conteúdo anterior na tabela
        tbody.innerHTML = '';

        // 2. Itera sobre os itens recebidos e cria as linhas da tabela
        data.items.forEach(function(item) {
            const row = document.createElement('tr');
            
            // Função auxiliar para criar células de texto
            const createTextCell = (text) => {
                const cell = document.createElement('td');
                cell.textContent = text ?? '';
                return cell;
            };

            // Adiciona as células de dados
            row.appendChild(createTextCell(item['id']));
            row.appendChild(createTextCell(item['nome']));
            row.appendChild(createTextCell(item['endereco']));
            row.appendChild(createTextCell(item['responsavel']));

            // Adiciona a célula de Ações
            const actionsCell = document.createElement('td');
            actionsCell.innerHTML = `<a class='btn' href='visualizar_armazen.html?id=${item.id}'>Ver</a>`;
            row.appendChild(actionsCell);

            // Adiciona a linha completa ao corpo da tabela
            tbody.appendChild(row);
        });
    })
    .catch(error => {
        // Trata erros de conexão ou requisição (rede)
        console.error(error);
        document.getElementById('msg').textContent = 'Erro na requisição';
    });