// Obtém o formulário de inserção
const form = document.getElementById('formIns');

// --- 1. Lógica de Preenchimento Dinâmico de Selects ---

document.addEventListener('DOMContentLoaded', () => {
    // Mapeia o nome do campo SELECT (name) para o endpoint PHP que fornece os dados
    const endpointMap = {
        'unidade_id': '../php/unidades/get_all.php',
        'armazem_id': '../php/armazens/get_all.php',
        'local_id': '../php/locais/get_all.php',
        'item_id': '../php/itens/get_all.php',
        'usuario_id': '../php/usuarios/get_all.php'
    };
    
    // Itera sobre o mapa para buscar dados e popular cada SELECT
    Object.keys(endpointMap).forEach(name => {
        const selectElement = document.querySelector('select[name="' + name + '"]');
        
        // Se o SELECT não existir na página atual, ignora
        if (!selectElement) return;

        // Faz a requisição para buscar os dados
        fetch(endpointMap[name])
            .then(response => response.json())
            .then(data => {
                // Se a requisição falhar ou não retornar sucesso, para a execução
                if (!data.success) return;
                
                // Limpa e adiciona a opção padrão
                selectElement.innerHTML = '<option value="">-- selecione --</option>';
                
                // Itera sobre os itens recebidos e cria as novas opções
                data.items.forEach(item => {
                    const option = document.createElement('option');
                    option.value = item.id;
                    
                    // Define o texto da opção, priorizando 'nome', 'sigla', ou 'email'
                    option.textContent = item.nome 
                                      ?? item.sigla 
                                      ?? item.email 
                                      ?? ('#' + item.id);
                                      
                    selectElement.appendChild(option);
                });
            })
            .catch(() => {
                // Silencia erros de requisição para preenchimento de selects
            });
    });
});

// --- 2. Lógica de Submissão do Formulário de Inserção ---

form.addEventListener('submit', function(e) {
    e.preventDefault(); 
    
    const formData = new FormData(form);
    const messageElement = document.getElementById('msg');

    // Determina o módulo atual (ex: 'itens', 'locais', 'armazens') a partir da URL
    const pathParts = window.location.pathname.split('/');
    // Pega o penúltimo segmento da URL
    const module = pathParts[pathParts.length - 2]; 

    // Constrói o caminho dinamicamente (ex: '../php/itens/inserir.php')
    fetch('../php/' + module + '/inserir.php', { 
        method: 'POST', 
        body: formData 
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            messageElement.textContent = 'Inserido.';
            // Redireciona para a página de listagem após um pequeno atraso
            setTimeout(() => location.href = 'index.html', 700); 
        } else {
            messageElement.textContent = data.message || 'Erro';
        }
    })
    .catch(error => {
        console.error(error);
        messageElement.textContent = 'Erro na requisição';
    });
});