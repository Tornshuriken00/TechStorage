// Obtém o corpo da tabela onde as linhas serão inseridas
const tbody = document.querySelector('#table tbody');
const messageElement = document.getElementById('msg');

// Faz a requisição para buscar a lista de transações
fetch('../php/transacoes/get_all.php')
    .then(response => response.json())
    .then(data => {
        // 1. Verifica o sucesso da requisição PHP
        if (!data.success) {
            messageElement.textContent = data.message || 'Erro';
            return;
        }

        // Limpa qualquer conteúdo anterior na tabela
        tbody.innerHTML = '';

        // 2. Itera sobre os itens recebidos e cria as linhas da tabela
        data.items.forEach(function(item) {
            const row = document.createElement('tr');
            
            // Função auxiliar para criar células de texto
            const createTextCell = (text) => {
                const cell = document.createElement('td');
                // Usa o operador de coalescência nula (??) para garantir string vazia se nulo/undefined
                cell.textContent = text ?? ''; 
                return cell;
            };

            // Adiciona as células de dados na ordem correta
            row.appendChild(createTextCell(item['id']));
            row.appendChild(createTextCell(item['tipo']));
            row.appendChild(createTextCell(item['item_id']));
            row.appendChild(createTextCell(item['quantidade']));
            row.appendChild(createTextCell(item['data']));
            row.appendChild(createTextCell(item['local_id']));
            row.appendChild(createTextCell(item['usuario_id']));
            row.appendChild(createTextCell(item['observacao']));

            // Adiciona a célula de Ações
            const actionsCell = document.createElement('td');
            actionsCell.innerHTML = `<a class='btn' href='visualizar_transacoe.html?id=${item.id}'>Ver</a>`;
            row.appendChild(actionsCell);

            // Adiciona a linha completa ao corpo da tabela
            tbody.appendChild(row);
        });
    })
    .catch(error => {
        // Trata erros de conexão ou requisição (rede)
        console.error(error);
        messageElement.textContent = 'Erro na requisição';
    });