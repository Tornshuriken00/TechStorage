/*
session.js - versão mais resiliente com logs de depuração
- Tenta detectar paths relativos e absolutos
- Tenta múltiplos endpoints: /php/whoami.php, php/whoami.php, ./php/whoami.php
- Usa credentials: 'include' para maximizar compatibilidade
*/
(function(){
    const candidates = [
        '/php/whoami.php',
        'php/whoami.php',
        './php/whoami.php',
        '../php/whoami.php'
    ];
    const logoutCandidates = [
        '/php/logout.php',
        'php/logout.php',
        './php/logout.php',
        '../php/logout.php'
    ];

    function debug(...args){ try{ console.log('[session.js]', ...args);}catch(e){} }

    function fetchWhoami(url) {
        debug('Tentando whoami em', url);
        return fetch(url, {method:'GET', credentials:'include'})
            .then(r=>{ if (!r.ok) throw new Error('HTTP '+r.status); return r.json(); });
    }

    function tryWhoami(list){
        if (!list.length) return Promise.reject('Nenhum endpoint disponível');
        const url = list[0];
        return fetchWhoami(url)
            .catch(err=>{
                debug('Falha em', url, err);
                return tryWhoami(list.slice(1));
            });
    }

    function tryLogout(list){
        if (!list.length) return Promise.reject('Nenhum endpoint logout');
        const url = list[0];
        return fetch(url, {method:'POST', credentials:'include'})
            .then(r=>{ if (!r.ok) throw new Error('HTTP '+r.status); return r.json(); })
            .catch(err=>{
                debug('Falha logout em', url, err);
                return tryLogout(list.slice(1));
            });
    }

    function createSessionBox(user, logoutUrl){
        const container = document.createElement('div');
        container.id = 'session-box';
        container.style.display = 'flex';
        container.style.alignItems = 'center';
        container.style.gap = '8px';
        container.style.marginLeft = '12px';

        const txt = document.createElement('span');
        txt.textContent = user.nome ? (user.nome + ' (' + (user.email||'sem email') + ')') : (user.email || 'Usuário');
        txt.style.fontSize = '0.95rem';

        const btn = document.createElement('button');
        btn.textContent = 'Sair';
        btn.className = 'btn small';
        btn.onclick = function(e){
            e.preventDefault();
            if (!confirm('Deseja realmente sair?')) return;
            tryLogout(logoutCandidates)
            .then(d=>{
                if (d && d.success) {
                    window.location.href = '/login.html';
                } else {
                    alert('Erro ao deslogar');
                }
            }).catch(()=>alert('Erro na requisição de logout'));
        };

        container.appendChild(txt);
        container.appendChild(btn);
        return container;
    }

    function insertIntoHeader(user){
        const headers = document.getElementsByTagName('header');
        const header = headers.length ? headers[0] : null;
        if (!header) {
            // tenta inserir no body top-right
            const body = document.body;
            const top = document.createElement('div');
            top.style.position = 'fixed';
            top.style.top = '8px';
            top.style.right = '8px';
            top.style.zIndex = '9999';
            top.id = 'session-box-wrapper';
            top.appendChild(createSessionBox(user));
            body.appendChild(top);
            return;
        }
        let right = header.querySelector('.session-area');
        if (!right) {
            right = document.createElement('div');
            right.className = 'session-area';
            right.style.marginLeft = 'auto';
            right.style.display = 'flex';
            right.style.alignItems = 'center';
            header.appendChild(right);
        }
        // evita duplicar
        if (right.querySelector('#session-box')) return;
        right.appendChild(createSessionBox(user));
    }

    function init(){
        tryWhoami(candidates)
        .then(d=>{
            debug('Resposta whoami:', d);
            if (!d || !d.logged) {
                debug('Nenhum usuário logado detectado.');
                return;
            }
            const user = d.user || {};
            insertIntoHeader(user);
        })
        .catch(err=>{
            debug('Erro geral ao verificar sessão:', err);
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();