// Obtém o elemento onde o conteúdo será exibido
const container = document.getElementById('conteudo'); 

// Obtém os parâmetros da URL
const params = new URLSearchParams(window.location.search); 
const id = params.get('id');

// 1. Verifica se o ID foi fornecido na URL
if (!id) {
    container.textContent = 'ID não informado';
} else {
    // 2. Faz a requisição para o endpoint PHP, passando o ID
    fetch('../php/itens/get_one.php?id=' + id)
        .then(response => response.json())
        .then(data => {
            // Verifica se a requisição PHP foi bem-sucedida
            if (!data.success) {
                container.textContent = data.message || 'Erro';
                return;
            }
            
            // 3. Exibe os dados do item formatados como JSON legível
            // O uso de JSON.stringify(..., null, 2) formata o JSON com indentação de 2 espaços.
            container.innerHTML = '<pre>' + JSON.stringify(data.item, null, 2) + '</pre>';
        })
        .catch(error => {
            // Trata erros de conexão ou requisição (rede)
            console.error(error);
            container.textContent = 'Erro na requisição';
        });
}