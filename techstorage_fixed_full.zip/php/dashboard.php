<?php

// Define o cabeçalho para garantir que a resposta seja JSON
header('Content-Type: application/json; charset=utf-8');

// Inclui o arquivo de conexão com o banco de dados
require_once 'conexao.php';

// Inicializa a estrutura de resposta JSON
$res = [
    'success' => true,
    'summary' => []
];

// --- 1. Contagem Total de Itens ---
$q = $conn->query('SELECT COUNT(*) AS c FROM itens');
$res['summary']['total_itens'] = ($q ? ($q->fetch_assoc()['c'] ?? 0) : 0);

// --- 2. Contagem Total de Armazéns ---
$q = $conn->query('SELECT COUNT(*) AS c FROM armazens');
$res['summary']['total_armazens'] = ($q ? ($q->fetch_assoc()['c'] ?? 0) : 0);

// --- 3. Contagem Total de Unidades ---
$q = $conn->query('SELECT COUNT(*) AS c FROM unidades');
$res['summary']['total_unidades'] = ($q ? ($q->fetch_assoc()['c'] ?? 0) : 0);

// 4. Retorna a resposta JSON
echo json_encode($res);

?>