<?php

// Define o cabeçalho para garantir que a resposta seja JSON
header('Content-Type: application/json; charset=utf-8');

// Inclui o arquivo de conexão
require_once __DIR__ . '/../conexao.php';

// 1. Coleta e sanitiza os dados de entrada
$tipo       = $_POST['tipo'] ?? null;
$item_id    = intval($_POST['item_id'] ?? 0);
$quantidade = floatval($_POST['quantidade'] ?? 0);
$local_id   = intval($_POST['local_id'] ?? 0);
$usuario_id = intval($_POST['usuario_id'] ?? 0);
$observacao = trim($_POST['observacao'] ?? '');

// 2. Validação inicial dos dados
if (!$tipo || !$item_id || $quantidade <= 0) {
    echo json_encode(['success' => false, 'message' => 'Dados obrigatórios inválidos']);
    exit;
}
if (!in_array($tipo, ['entrada', 'saida'])) {
    echo json_encode(['success' => false, 'message' => 'Tipo de transação inválido']);
    exit;
}

// 3. Inicia a Transação: Garante que ou TUDO é salvo, ou NADA é salvo.
$conn->begin_transaction();

try {
    // --- LÓGICA DE ATUALIZAÇÃO DO ESTOQUE ---
    
    if ($tipo === 'entrada') {
        // Apenas adiciona ao estoque (entrada)
        $stmt = $conn->prepare('UPDATE itens SET quantidade = quantidade + ? WHERE id = ?');
        $stmt->bind_param('di', $quantidade, $item_id); // 'd' para float (double), 'i' para int
        $stmt->execute();
        
    } else { // tipo === 'saida'
        // 3a. Verifica o estoque atual antes de subtrair, usando FOR UPDATE para bloquear a linha.
        $stmt = $conn->prepare('SELECT quantidade FROM itens WHERE id = ? FOR UPDATE');
        $stmt->bind_param('i', $item_id);
        $stmt->execute();
        $res = $stmt->get_result();

        if ($res->num_rows === 0) {
            throw new Exception('Item não encontrado');
        }
        
        $row = $res->fetch_assoc();
        
        // 3b. Verifica se há estoque suficiente
        if ($row['quantidade'] < $quantidade) {
            throw new Exception('Quantidade insuficiente no estoque');
        }
        
        // 3c. Subtrai do estoque (saída)
        $stmt = $conn->prepare('UPDATE itens SET quantidade = quantidade - ? WHERE id = ?');
        $stmt->bind_param('di', $quantidade, $item_id);
        $stmt->execute();
    }
    
    // --- REGISTRO DA TRANSAÇÃO ---
    
    // 4. Insere o registro na tabela de transações
    $stmt = $conn->prepare('INSERT INTO transacoes (tipo, item_id, quantidade, data, local_id, usuario_id, observacao) VALUES (?, ?, ?, ?, ?, ?, ?)');
    
    $now = date('Y-m-d H:i:s');
    // Tipos: s (string), d (double/float), i (integer)
    $stmt->bind_param('sdisiis', $tipo, $item_id, $quantidade, $now, $local_id, $usuario_id, $observacao);
    $stmt->execute();
    
    // 5. Confirma a transação (salva todas as alterações)
    $conn->commit();
    echo json_encode(['success' => true]);

} catch (Exception $e) {
    // 6. Em caso de erro (estoque insuficiente, item não encontrado, erro SQL), desfaz tudo
    $conn->rollback();
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}

?>