<?php

// Define o cabeçalho para garantir que a resposta seja JSON
header('Content-Type: application/json; charset=utf-8');

// Inclui o arquivo de conexão com o banco de dados
require_once 'conexao.php';

// 1. Coleta e sanitiza os dados de entrada
$nome  = trim($_POST['nome'] ?? '');
$email = trim($_POST['email'] ?? '');
$senha = $_POST['senha'] ?? '';
$cargo = $_POST['cargo'] ?? 'funcionario'; // Define 'funcionario' como padrão

// 2. Validação básica de campos obrigatórios
if (!$nome || !$email || !$senha) {
    echo json_encode(['success' => false, 'message' => 'Campos obrigatórios']);
    exit;
}

// 3. Verifica se o e-mail já está cadastrado
$stmt = $conn->prepare('SELECT id FROM usuarios WHERE email = ? LIMIT 1');
$stmt->bind_param('s', $email);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows > 0) {
    echo json_encode(['success' => false, 'message' => 'Email já cadastrado']);
    exit;
}
$stmt->close();

// 4. Cria o hash seguro da senha
$hash = password_hash($senha, PASSWORD_DEFAULT);

// 5. Insere o novo usuário no banco de dados
$stmt = $conn->prepare('INSERT INTO usuarios (nome, email, senha, cargo, criado_em) VALUES (?, ?, ?, ?, NOW())');
$stmt->bind_param('ssss', $nome, $email, $hash, $cargo);

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'OK']);
} else {
    // Retorna mensagem de erro do banco de dados, se houver
    echo json_encode(['success' => false, 'message' => $conn->error]);
}

// O script termina aqui
?>