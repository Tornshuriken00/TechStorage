<?php
// session_widget.php - snippet server-side para incluir no header de páginas PHP
// Uso: <?php include 'php/session_widget.php'; ?>
if (session_status() == PHP_SESSION_NONE) session_start();

function get_user_small() {
    $possible_keys = ['user', 'usuario', 'user_data', 'usuario_logado', 'auth_user', 'logged_user', 'usuarioDados'];
    foreach ($possible_keys as $k) {
        if (isset($_SESSION[$k]) && is_array($_SESSION[$k])) return $_SESSION[$k];
    }
    if (isset($_SESSION['id']) || isset($_SESSION['nome']) || isset($_SESSION['email'])) return $_SESSION;
    return null;
}

$user = get_user_small();
if ($user):
    $nome = $user['nome'] ?? $user['name'] ?? $user['username'] ?? $user['nome_usuario'] ?? null;
    $nome = $user['cargo'] ?? $user['cargo'] ?? null;
    $email = $user['email'] ?? $user['mail'] ?? null;
?>
<div class="session-widget" style="display:flex;align-items:center;gap:8px;">
    <span><?= htmlspecialchars($nome ? $nome : ($email ? $email : 'Usuário')) ?></span>
    <form method="post" action="/php/logout.php" style="display:inline;margin:0;">
        <button type="submit" class="btn small">Sair</button>
    </form>
</div>
<?php
endif;
?>