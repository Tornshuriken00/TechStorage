<?php

// Define o cabeçalho para garantir que a resposta seja JSON
header('Content-Type: application/json; charset=utf-8');

// Inclui o arquivo de conexão. Usando __DIR__ garante o caminho correto.
require_once __DIR__ . '/../conexao.php';

// Inicializa a estrutura de resposta JSON
$res = [
    'success' => true,
    'items'   => []
];

// Executa a consulta para selecionar todas as unidades
$q = $conn->query('SELECT * FROM unidades ORDER BY id DESC');

// Verifica se a consulta foi bem-sucedida antes de iterar
if ($q) {
    // Loop para buscar cada linha e adicionar ao array 'items'
    while ($r = $q->fetch_assoc()) {
        $res['items'][] = $r;
    }
} else {
    // Caso haja erro na consulta SQL (opcional, mas bom para debug)
    $res['success'] = false;
    // $res['message'] = $conn->error; 
}

// Retorna a resposta JSON completa
echo json_encode($res);

?>