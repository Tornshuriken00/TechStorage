<?php

// Define o cabeçalho para garantir que a resposta seja JSON
header('Content-Type: application/json; charset=utf-8');
session_start();

// Inclui o arquivo de conexão com o banco de dados
require_once 'conexao.php';

// 1. Coleta e sanitiza os dados de entrada
$email = trim($_POST['email'] ?? '');
$senha = $_POST['senha'] ?? '';

// 2. Validação básica de entrada
if (!$email || !$senha) {
    echo json_encode(['success' => false, 'message' => 'Email e senha são obrigatórios.']);
    exit;
}

// 3. Prepara a consulta para buscar o usuário pelo email
$stmt = $conn->prepare('SELECT id, nome, email, senha, cargo, criado_em FROM usuarios WHERE email = ? LIMIT 1');
$stmt->bind_param('s', $email);
$stmt->execute();
$res = $stmt->get_result();

// 4. Verifica se o usuário foi encontrado
if ($res->num_rows === 0) {
    echo json_encode(['success' => false, 'message' => 'Usuário não encontrado.']);
    exit;
}

// 5. Busca os dados do usuário e verifica a senha
$row = $res->fetch_assoc();

if (password_verify($senha, $row['senha'])) {
    // Login bem-sucedido: Limpa a senha do array e armazena os dados na sessão
    unset($row['senha']);
    $_SESSION['user'] = $row;
    
    echo json_encode(['success' => true, 'message' => 'Login ok.']);
} else {
    // Senha incorreta
    echo json_encode(['success' => false, 'message' => 'Senha incorreta.']);
}

// O script termina aqui após o output de JSON
?>