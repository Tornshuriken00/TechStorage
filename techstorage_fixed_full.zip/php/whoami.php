<?php
// whoami.php - versão reforçada
session_start();
header('Content-Type: application/json; charset=utf-8');
// Evita caching
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

// Função utilitária para obter o usuário da sessão a partir de várias chaves possíveis
function get_session_user() {
    $possible_keys = ['user', 'usuario', 'user_data', 'usuario_logado', 'auth_user', 'logged_user', 'usuarioDados'];
    foreach ($possible_keys as $k) {
        if (isset($_SESSION[$k]) && is_array($_SESSION[$k])) {
            return $_SESSION[$k];
        }
    }
    // se houver uma única id/nome diretamente em $_SESSION
    if (isset($_SESSION['id']) || isset($_SESSION['nome']) || isset($_SESSION['email'])) {
        return $_SESSION;
    }
    return null;
}

$user = get_session_user();
if (!$user) {
    echo json_encode(['logged' => false]);
    exit;
}

// Remover campos sensíveis
$sensitive = ['senha','password','pwd','pass','secret','token','access_token'];
foreach ($sensitive as $s) {
    if (isset($user[$s])) unset($user[$s]);
}

// Normalizar campos
$nome = $user['nome'] ?? $user['name'] ?? $user['username'] ?? $user['nome_usuario'] ?? null;
$email = $user['email'] ?? $user['mail'] ?? null;
$id = $user['id'] ?? $user['user_id'] ?? null;

echo json_encode([
    'logged' => true,
    'user' => [
        'id' => $id,
        'nome' => $nome,
        'email' => $email,
        'raw' => $user
    ]
]);
?>