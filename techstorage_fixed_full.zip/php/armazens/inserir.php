<?php

// Define o cabeçalho para garantir que a resposta seja JSON
header('Content-Type: application/json; charset=utf-8');

// Inclui o arquivo de conexão
require_once __DIR__ . '/../conexao.php';

// Inicializa arrays para construir a consulta SQL
$cols  = [];    // Nomes das colunas
$vals  = [];    // Marcadores de valor ('?')
$types = '';    // String dos tipos de dados ('s' para string)
$binds = [];    // Valores reais a serem ligados

// 1. Itera sobre os dados POST para construir dinamicamente a consulta
foreach ($_POST as $k => $v) {
    // Ignora chaves vazias ou dados irrelevantes
    if ($k === '') continue; 
    
    $cols[] = $k;
    $vals[] = '?';
    $types .= 's'; // Assume 's' (string) para todos os dados de POST por segurança
    $binds[] = $v;
}

// 2. Validação: Verifica se algum dado foi enviado
if (count($cols) === 0) {
    echo json_encode(['success' => false, 'message' => 'Nenhum dado enviado']);
    exit;
}

// 3. Constrói a string SQL de INSERT
$sql = 'INSERT INTO armazens (' . implode(',', $cols) . ') VALUES (' . implode(',', $vals) . ')';

// 4. Prepara o statement
$stmt = $conn->prepare($sql);

// 5. Liga os parâmetros dinamicamente (Método avançado para binding)
$refs = array(); 
foreach ($binds as $i => $b) { 
    $refs[] = &$binds[$i]; // Passa a REFERÊNCIA de cada valor
}
array_unshift($refs, $types); // Adiciona a string de tipos ('sss...') no início do array
call_user_func_array(array($stmt, 'bind_param'), $refs); // Executa bind_param com o array de referências

// 6. Executa a inserção e retorna o resultado
if ($stmt->execute()) {
    echo json_encode(['success' => true]);
} else {
    // Retorna a mensagem de erro do banco de dados
    echo json_encode(['success' => false, 'message' => $conn->error]);
}
?>