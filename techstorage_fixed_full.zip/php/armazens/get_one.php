<?php

// Define o cabeçalho para garantir que a resposta seja JSON
header('Content-Type: application/json; charset=utf-8');

// Inclui o arquivo de conexão
require_once __DIR__ . '/../conexao.php';

// 1. Coleta e sanitiza o ID da URL
// Garante que o ID seja um inteiro.
$id = intval($_GET['id'] ?? 0);

// 2. Validação do ID
if (!$id) {
    echo json_encode(['success' => false, 'message' => 'ID inválido']);
    exit;
}

// 3. Prepara a consulta para buscar o armazém pelo ID (usando Prepared Statement)
$stmt = $conn->prepare('SELECT * FROM armazens WHERE id = ? LIMIT 1');
$stmt->bind_param('i', $id); // 'i' indica que o parâmetro é um inteiro
$stmt->execute();
$res = $stmt->get_result();

// 4. Verifica se o armazém foi encontrado
if ($res->num_rows === 0) {
    echo json_encode(['success' => false, 'message' => 'Não encontrado']);
    exit;
}

// 5. Busca os dados e retorna o sucesso
$row = $res->fetch_assoc();

echo json_encode([
    'success' => true,
    'item'    => $row
]);

// O script termina aqui
?>