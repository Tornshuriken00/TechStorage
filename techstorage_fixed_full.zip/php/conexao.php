<?php

// 1. Configurações do Banco de Dados
$DB_HOST = 'localhost';
$DB_USER = 'root';
$DB_PASS = ''; // Geralmente vazio em ambientes de desenvolvimento (local)
$DB_NAME = 'techstorage';

// 2. Estabelece a Conexão
$conn = new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);

// 3. Trata Erros de Conexão
if ($conn->connect_error) {
    // Define o código de resposta HTTP como 500 (Erro Interno do Servidor)
    http_response_code(500); 
    
    // Retorna um JSON de erro
    echo json_encode([
        'success' => false, 
        'message' => 'Erro: ' . $conn->connect_error
    ]);
    exit;
}

// 4. Configura o Charset
// Define o charset para 'utf8mb4' para suportar emojis e caracteres especiais
$conn->set_charset('utf8mb4');

// O objeto de conexão ($conn) está agora pronto para ser usado por outros scripts
?>