<?php

// Define o cabeçalho para garantir que a resposta seja JSON
header('Content-Type: application/json; charset=utf-8');

// Inclui o arquivo de conexão. Usando __DIR__ garante o caminho correto.
require_once __DIR__ . '/../conexao.php';

// Inicializa a estrutura de resposta JSON
$res = [
    'success' => true,
    'items'   => []
];

// Executa a consulta para selecionar todos os usuários (apenas dados não sensíveis)
$q = $conn->query('SELECT id, nome, email FROM usuarios ORDER BY id DESC');

// Verifica se a consulta foi bem-sucedida antes de iterar
if ($q) {
    // Loop para buscar cada linha e adicionar ao array 'items'
    while ($r = $q->fetch_assoc()) {
        $res['items'][] = $r;
    }
} else {
    // Caso haja erro na consulta SQL (embora não seja retornado no JSON original, é bom ter)
    $res['success'] = false;
    // $res['message'] = $conn->error; // Você pode adicionar a mensagem de erro para debug
}

// Retorna a resposta JSON completa
echo json_encode($res);

?>