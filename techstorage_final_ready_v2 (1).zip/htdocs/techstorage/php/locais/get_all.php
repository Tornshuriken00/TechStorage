<?php
header('Content-Type: application/json; charset=utf-8'); require_once __DIR__.'/../conexao.php'; $res=['success'=>true,'items'=>[]]; $q = $conn->query('SELECT * FROM locais ORDER BY id DESC'); while($r = $q->fetch_assoc()) $res['items'][] = $r; echo json_encode($res);
?>