<?php
header('Content-Type: application/json; charset=utf-8'); require_once __DIR__.'/../conexao.php';
$cols = []; $vals = []; $types = ''; $binds = [];
foreach($_POST as $k=>$v){ if($k==='') continue; $cols[] = $k; $vals[] = '?'; $types .= 's'; $binds[] = $v; }
if(count($cols)===0){ echo json_encode(['success'=>false,'message'=>'Nenhum dado enviado']); exit; }
$sql = 'INSERT INTO unidades ('.implode(',', $cols).') VALUES ('.implode(',', $vals).')';
$stmt = $conn->prepare($sql);
// bind params dynamically
$refs = array(); foreach($binds as $i=>$b){ $refs[] = & $binds[$i]; }
array_unshift($refs, $types);
call_user_func_array(array($stmt,'bind_param'), $refs);
if($stmt->execute()) echo json_encode(['success'=>true]); else echo json_encode(['success'=>false,'message'=>$conn->error]);
?>