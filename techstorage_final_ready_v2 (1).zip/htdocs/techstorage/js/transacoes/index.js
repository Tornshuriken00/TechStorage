const tbody = document.querySelector('#table tbody');
fetch('../php/transacoes/get_all.php').then(r=>r.json()).then(d=>{
  if(!d.success){ document.getElementById('msg').textContent=d.message||'Erro'; return; }
  tbody.innerHTML='';
  d.items.forEach(function(it){
    const tr = document.createElement('tr');
    let td_id = document.createElement('td'); td_id.textContent = it['id'] ?? ''; tr.appendChild(td_id);
    let td_tipo = document.createElement('td'); td_tipo.textContent = it['tipo'] ?? ''; tr.appendChild(td_tipo);
    let td_item_id = document.createElement('td'); td_item_id.textContent = it['item_id'] ?? ''; tr.appendChild(td_item_id);
    let td_quantidade = document.createElement('td'); td_quantidade.textContent = it['quantidade'] ?? ''; tr.appendChild(td_quantidade);
    let td_data = document.createElement('td'); td_data.textContent = it['data'] ?? ''; tr.appendChild(td_data);
    let td_local_id = document.createElement('td'); td_local_id.textContent = it['local_id'] ?? ''; tr.appendChild(td_local_id);
    let td_usuario_id = document.createElement('td'); td_usuario_id.textContent = it['usuario_id'] ?? ''; tr.appendChild(td_usuario_id);
    let td_observacao = document.createElement('td'); td_observacao.textContent = it['observacao'] ?? ''; tr.appendChild(td_observacao);
    let td_actions = document.createElement('td'); td_actions.innerHTML = "<a class='btn' href='visualizar_transacoe.html?id="+it.id+"'>Ver</a>"; tr.appendChild(td_actions);
    tbody.appendChild(tr);
  });
}).catch(err=>{ console.error(err); document.getElementById('msg').textContent='Erro na requisição'; });