const tbody = document.querySelector('#table tbody');
fetch('../php/armazens/get_all.php').then(r=>r.json()).then(d=>{
  if(!d.success){ document.getElementById('msg').textContent=d.message||'Erro'; return; }
  tbody.innerHTML='';
  d.items.forEach(function(it){
    const tr = document.createElement('tr');
    let td_id = document.createElement('td'); td_id.textContent = it['id'] ?? ''; tr.appendChild(td_id);
    let td_nome = document.createElement('td'); td_nome.textContent = it['nome'] ?? ''; tr.appendChild(td_nome);
    let td_endereco = document.createElement('td'); td_endereco.textContent = it['endereco'] ?? ''; tr.appendChild(td_endereco);
    let td_responsavel = document.createElement('td'); td_responsavel.textContent = it['responsavel'] ?? ''; tr.appendChild(td_responsavel);
    let td_actions = document.createElement('td'); td_actions.innerHTML = "<a class='btn' href='visualizar_armazen.html?id="+it.id+"'>Ver</a>"; tr.appendChild(td_actions);
    tbody.appendChild(tr);
  });
}).catch(err=>{ console.error(err); document.getElementById('msg').textContent='Erro na requisição'; });