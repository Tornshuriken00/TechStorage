const form = document.getElementById('formIns');
document.addEventListener('DOMContentLoaded', ()=>{
  const map = {
    'unidade_id': '../php/unidades/get_all.php',
    'armazem_id': '../php/armazens/get_all.php',
    'local_id': '../php/locais/get_all.php',
    'item_id': '../php/itens/get_all.php',
    'usuario_id': '../php/usuarios/get_all.php'
  };
  Object.keys(map).forEach(name => {
    const sel = document.querySelector('select[name="'+name+'"]');
    if(!sel) return;
    fetch(map[name]).then(r=>r.json()).then(d=>{
      if(!d.success) return;
      sel.innerHTML = '<option value="">-- selecione --</option>';
      d.items.forEach(x=>{ const opt = document.createElement('option'); opt.value = x.id; opt.textContent = x.nome ?? x.sigla ?? x.email ?? ('#'+x.id); sel.appendChild(opt); });
    }).catch(()=>{});
  });
});
form.addEventListener('submit', function(e){
  e.preventDefault(); const fd = new FormData(form);
  const pathParts = window.location.pathname.split('/');
  const module = pathParts[pathParts.length-2];
  fetch('../php/' + module + '/inserir.php', { method:'POST', body:fd }).then(r=>r.json()).then(d=>{ if(d.success){ document.getElementById('msg').textContent='Inserido.'; setTimeout(()=>location.href='index.html',700); } else document.getElementById('msg').textContent = d.message || 'Erro'; }).catch(err=>{ console.error(err); document.getElementById('msg').textContent='Erro na requisição'; });
});