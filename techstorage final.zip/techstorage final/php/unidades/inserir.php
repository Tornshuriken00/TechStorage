<?php

// Define o cabeçalho para garantir que a resposta seja JSON
header('Content-Type: application/json; charset=utf-8');

// Inclui o arquivo de conexão
require_once __DIR__ . '/../conexao.php';

// Inicializa arrays para construir a consulta SQL
$cols  = [];    // Nomes das colunas
$vals  = [];    // Marcadores de valor ('?')
$types = '';    // String dos tipos de dados ('s' para string, 'i' para int, etc.)
$binds = [];    // Valores reais a serem ligados

// 1. Itera sobre os dados POST para construir dinamicamente a consulta
foreach ($_POST as $k => $v) {
    // Ignora chaves vazias ou dados que não deveriam ir para o banco (ex: token de segurança)
    if ($k === '') continue; 
    
    $cols[] = $k;
    $vals[] = '?';
    $types .= 's'; // Assume que todos os dados de POST são strings para bind
    $binds[] = $v;
}

// 2. Validação: Verifica se algum dado foi enviado
if (count($cols) === 0) {
    echo json_encode(['success' => false, 'message' => 'Nenhum dado enviado']);
    exit;
}

// 3. Constrói a string SQL de INSERT
$sql = 'INSERT INTO unidades (' . implode(', ', $cols) . ') VALUES (' . implode(', ', $vals) . ')';

// 4. Prepara o statement
$stmt = $conn->prepare($sql);

// 5. Liga os parâmetros dinamicamente (Método avançado usando call_user_func_array)
$refs = array(); 
foreach ($binds as $i => $b) { 
    $