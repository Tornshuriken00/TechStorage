<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__.'/../conexao.php';
$tipo = $_POST['tipo'] ?? null;
$item_id = intval($_POST['item_id'] ?? 0);
$quantidade = floatval($_POST['quantidade'] ?? 0);
$local_id = intval($_POST['local_id'] ?? 0);
$usuario_id = intval($_POST['usuario_id'] ?? 0);
$observacao = trim($_POST['observacao'] ?? '');
if(!$tipo || !$item_id || $quantidade<=0){ echo json_encode(['success'=>false,'message'=>'Dados inválidos']); exit; }
if(!in_array($tipo, ['entrada','saida'])){ echo json_encode(['success'=>false,'message'=>'Tipo inválido']); exit; }
$conn->begin_transaction();
try {
  if($tipo === 'entrada'){
    $stmt = $conn->prepare('UPDATE itens SET quantidade = quantidade + ? WHERE id = ?');
    $stmt->bind_param('di', $quantidade, $item_id);
    $stmt->execute();
  } else {
    $stmt = $conn->prepare('SELECT quantidade FROM itens WHERE id = ? FOR UPDATE');
    $stmt->bind_param('i', $item_id);
    $stmt->execute();
    $res = $stmt->get_result();
    if($res->num_rows===0) throw new Exception('Item não encontrado');
    $row = $res->fetch_assoc();
    if($row['quantidade'] < $quantidade) throw new Exception('Quantidade insuficiente');
    $stmt = $conn->prepare('UPDATE itens SET quantidade = quantidade - ? WHERE id = ?');
    $stmt->bind_param('di', $quantidade, $item_id);
    $stmt->execute();
  }
  $stmt = $conn->prepare('INSERT INTO transacoes (tipo,item_id,quantidade,data,local_id,usuario_id,observacao) VALUES (?,?,?,?,?,?,?)');
  $now = date('Y-m-d H:i:s');
  $stmt->bind_param('sdisiis', $tipo, $item_id, $quantidade, $now, $local_id, $usuario_id, $observacao);
  $stmt->execute();
  $conn->commit();
  echo json_encode(['success'=>true]);
} catch(Exception $e){
  $conn->rollback();
  echo json_encode(['success'=>false,'message'=>$e->getMessage()]);
}
?>