<?php
header('Content-Type: application/json; charset=utf-8');
require_once 'conexao.php';
$res = ['success'=>true];
$q = $conn->query('SELECT COUNT(*) AS c FROM itens');
$res['summary']['total_itens'] = $q->fetch_assoc()['c'] ?? 0;
$q = $conn->query('SELECT COUNT(*) AS c FROM armazens');
$res['summary']['total_armazens'] = $q->fetch_assoc()['c'] ?? 0;
$q = $conn->query('SELECT COUNT(*) AS c FROM unidades');
$res['summary']['total_unidades'] = $q->fetch_assoc()['c'] ?? 0;
$q = $conn->query('SELECT t.tipo, t.quantidade, t.data, i.nome AS nome_item FROM transacoes t JOIN itens i ON t.item_id = i.id ORDER BY t.data DESC LIMIT 10');
$res['transacoes'] = [];
while($row = $q->fetch_assoc()) $res['transacoes'][] = $row;
echo json_encode($res);
?>