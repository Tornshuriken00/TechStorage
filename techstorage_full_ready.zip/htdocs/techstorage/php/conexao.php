<?php
$DB_HOST = 'localhost';
$DB_USER = 'root';
$DB_PASS = '';
$DB_NAME = 'techstorage';
$conn = new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);
if($conn->connect_error){
  http_response_code(500);
  echo json_encode(['success'=>false,'message'=>'Erro na conexão: '.$conn->connect_error]);
  exit;
}
$conn->set_charset('utf8mb4');
?>