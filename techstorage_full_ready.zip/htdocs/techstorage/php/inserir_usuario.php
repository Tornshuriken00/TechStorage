<?php
header('Content-Type: application/json; charset=utf-8');
require_once 'conexao.php';
$nome = trim($_POST['nome'] ?? '');
$email = trim($_POST['email'] ?? '');
$senha = $_POST['senha'] ?? '';
$cargo = $_POST['cargo'] ?? 'funcionario';
if(!$nome || !$email || !$senha){ echo json_encode(['success'=>false,'message'=>'Campos obrigatórios']); exit; }
$stmt = $conn->prepare('SELECT id FROM usuarios WHERE email = ? LIMIT 1');
$stmt->bind_param('s', $email); $stmt->execute(); $stmt->store_result();
if($stmt->num_rows>0) { echo json_encode(['success'=>false,'message'=>'Email já cadastrado']); exit; }
$hash = password_hash($senha, PASSWORD_DEFAULT);
$stmt = $conn->prepare('INSERT INTO usuarios (nome,email,senha,cargo,criado_em) VALUES (?,?,?,?,NOW())');
$stmt->bind_param('ssss', $nome, $email, $hash, $cargo);
if($stmt->execute()) echo json_encode(['success'=>true,'message'=>'OK']); else echo json_encode(['success'=>false,'message'=>$conn->error]);
?>