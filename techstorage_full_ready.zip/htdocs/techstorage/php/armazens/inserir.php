<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__.'/../conexao.php';
$nome = isset($_POST['nome']) ? $_POST['nome'] : null;
$endereco = isset($_POST['endereco']) ? $_POST['endereco'] : null;
$responsavel = isset($_POST['responsavel']) ? $_POST['responsavel'] : null;
$stmt = $conn->prepare('INSERT INTO armazens (nome,endereco,responsavel) VALUES (?,?,?)');
$stmt->bind_param('sss', $nome, $endereco, $responsavel);
if($stmt->execute()) echo json_encode(['success'=>true]); else echo json_encode(['success'=>false,'message'=>$conn->error]);
?>