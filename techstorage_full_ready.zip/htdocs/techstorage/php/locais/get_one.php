<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__.'/../conexao.php';
$id = intval($_GET['id'] ?? 0);
if(!$id){ echo json_encode(['success'=>false,'message'=>'ID inválido']); exit; }
$stmt = $conn->prepare('SELECT * FROM locais WHERE id = ? LIMIT 1');
$stmt->bind_param('i',$id);
$stmt->execute();
$res = $stmt->get_result();
if($res->num_rows===0){ echo json_encode(['success'=>false,'message'=>'Não encontrado']); exit; }
$row = $res->fetch_assoc();
echo json_encode(['success'=>true,'item'=>$row]);
?>