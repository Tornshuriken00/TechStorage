<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__.'/../conexao.php';
$nome = isset($_POST['nome']) ? $_POST['nome'] : null;
$descricao = isset($_POST['descricao']) ? $_POST['descricao'] : null;
$stmt = $conn->prepare('INSERT INTO locais (nome,descricao) VALUES (?,?)');
$stmt->bind_param('ss', $nome, $descricao);
if($stmt->execute()) echo json_encode(['success'=>true]); else echo json_encode(['success'=>false,'message'=>$conn->error]);
?>