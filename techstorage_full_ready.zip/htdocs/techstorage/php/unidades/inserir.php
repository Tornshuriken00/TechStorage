<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__.'/../conexao.php';
$nome = isset($_POST['nome']) ? $_POST['nome'] : null;
$sigla = isset($_POST['sigla']) ? $_POST['sigla'] : null;
$stmt = $conn->prepare('INSERT INTO unidades (nome,sigla) VALUES (?,?)');
$stmt->bind_param('ss', $nome, $sigla);
if($stmt->execute()) echo json_encode(['success'=>true]); else echo json_encode(['success'=>false,'message'=>$conn->error]);
?>