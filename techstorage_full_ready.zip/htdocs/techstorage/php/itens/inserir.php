<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__.'/../conexao.php';
$nome = isset($_POST['nome']) ? $_POST['nome'] : null;
$descricao = isset($_POST['descricao']) ? $_POST['descricao'] : null;
$unidade_id = isset($_POST['unidade_id']) ? $_POST['unidade_id'] : null;
$armazem_id = isset($_POST['armazem_id']) ? $_POST['armazem_id'] : null;
$quantidade = isset($_POST['quantidade']) ? $_POST['quantidade'] : null;
$stmt = $conn->prepare('INSERT INTO itens (nome,descricao,unidade_id,armazem_id,quantidade) VALUES (?,?,?,?,?)');
$stmt->bind_param('ssiis', $nome, $descricao, $unidade_id, $armazem_id, $quantidade);
if($stmt->execute()) echo json_encode(['success'=>true]); else echo json_encode(['success'=>false,'message'=>$conn->error]);
?>