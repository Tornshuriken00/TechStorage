const form = document.getElementById('formIns');
document.addEventListener('DOMContentLoaded', ()=>{
});
form.addEventListener('submit', function(e){ e.preventDefault(); const fd = new FormData(form); fetch('../php/unidades/inserir.php',{method:'POST', body:fd}).then(r=>r.json()).then(d=>{ if(d.success){ document.getElementById('msg').textContent='Inserido.'; setTimeout(()=>location.href='index.html',700);} else document.getElementById('msg').textContent=d.message||'Erro'; }).catch(err=>{ console.error(err); document.getElementById('msg').textContent='Erro na requisição'; }); });