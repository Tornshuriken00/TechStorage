const container = document.getElementById('conteudo');
const params = new URLSearchParams(window.location.search);
const id = params.get('id');
if(!id) container.textContent='ID não informado';
else fetch('../php/locais/get_one.php?id='+id).then(r=>r.json()).then(d=>{ if(!d.success){ container.textContent = d.message||'Erro'; return; } container.innerHTML = `<pre>${JSON.stringify(d.item,null,2)}</pre>`; }).catch(err=>{ console.error(err); container.textContent='Erro na requisição'; });