document.getElementById('logoutBtn').addEventListener('click', function(){
  fetch('php/logout.php', { method: 'POST' })
    .then(() => window.location.href = 'login.html')
    .catch(()=> window.location.href = 'login.html');
});
