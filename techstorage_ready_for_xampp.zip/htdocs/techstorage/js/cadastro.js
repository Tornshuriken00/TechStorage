document.getElementById('formCadastro').addEventListener('submit', function(e){
  e.preventDefault();
  const f = e.target;
  const formData = new FormData(f);
  fetch('php/inserir_usuario.php', {
    method: 'POST',
    body: formData
  }).then(r => r.json())
    .then(res => {
      const msg = document.getElementById('msg');
      if(res.success){
        msg.textContent = 'Cadastro realizado com sucesso. Redirecionando para login...';
        setTimeout(()=> window.location.href = 'login.html', 1200);
      } else {
        msg.textContent = res.message || 'Erro no cadastro';
      }
    }).catch(err => {
      console.error(err);
      document.getElementById('msg').textContent = 'Erro na requisição';
    });
});
