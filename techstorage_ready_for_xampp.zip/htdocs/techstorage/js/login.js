document.getElementById('formLogin').addEventListener('submit', function(e){
  e.preventDefault();
  const f = e.target;
  const formData = new FormData(f);
  fetch('php/autenticar_usuario.php', {
    method: 'POST',
    body: formData
  }).then(r => r.json())
    .then(res => {
      const msg = document.getElementById('msg');
      if(res.success){
        // redireciona para home
        window.location.href = 'index.html';
      } else {
        msg.textContent = res.message || 'Erro no login';
      }
    }).catch(err => {
      console.error(err);
      document.getElementById('msg').textContent = 'Erro na requisição';
    });
});
