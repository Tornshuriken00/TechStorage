-- Script SQL para criar o banco e a tabela 'usuarios'
CREATE DATABASE IF NOT EXISTS `techstorage` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `techstorage`;
CREATE TABLE IF NOT EXISTS `usuarios` (
  `id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `nome` VARCHAR(100) NOT NULL,
  `email` VARCHAR(150) NOT NULL UNIQUE,
  `senha` VARCHAR(255) NOT NULL,
  `cargo` ENUM('funcionario','gestor','admin') NOT NULL DEFAULT 'funcionario',
  `criado_em` DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
