<?php
header('Content-Type: application/json; charset=utf-8');
require_once 'conexao.php';
// Recebe POST
$nome = trim($_POST['nome'] ?? '');
$email = trim($_POST['email'] ?? '');
$senha = $_POST['senha'] ?? '';
$cargo = $_POST['cargo'] ?? '';
if(!$nome || !$email || !$senha || !$cargo){
  echo json_encode(['success'=>false,'message'=>'Todos os campos são obrigatórios.']);
  exit;
}
// valida cargo
$allowed = ['funcionario','gestor','admin'];
if(!in_array($cargo, $allowed)){
  echo json_encode(['success'=>false,'message'=>'Cargo inválido.']);
  exit;
}
// verifica se email já existe
$stmt = $conn->prepare('SELECT id FROM usuarios WHERE email = ? LIMIT 1');
$stmt->bind_param('s',$email);
$stmt->execute();
$stmt->store_result();
if($stmt->num_rows > 0){
  echo json_encode(['success'=>false,'message'=>'Email já cadastrado.']);
  $stmt->close();
  exit;
}
$stmt->close();
// insere usuário
$hash = password_hash($senha, PASSWORD_DEFAULT);
$stmt = $conn->prepare('INSERT INTO usuarios (nome,email,senha,cargo,criado_em) VALUES (?,?,?,?,NOW())');
$stmt->bind_param('ssss', $nome, $email, $hash, $cargo);
if($stmt->execute()){
  echo json_encode(['success'=>true,'message'=>'Cadastro realizado.']);
} else {
  echo json_encode(['success'=>false,'message'=>'Erro ao inserir: '. $conn->error]);
}
$stmt->close();
$conn->close();
?>