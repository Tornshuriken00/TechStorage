<?php
header('Content-Type: application/json; charset=utf-8');
session_start();
require_once 'conexao.php';
$email = trim($_POST['email'] ?? '');
$senha = $_POST['senha'] ?? '';
if(!$email || !$senha){
  echo json_encode(['success'=>false,'message'=>'Email e senha são obrigatórios.']);
  exit;
}
$stmt = $conn->prepare('SELECT id,nome,email,senha,cargo,criado_em FROM usuarios WHERE email = ? LIMIT 1');
$stmt->bind_param('s',$email);
$stmt->execute();
$res = $stmt->get_result();
if($res->num_rows === 0){
  echo json_encode(['success'=>false,'message'=>'Usuário não encontrado.']);
  exit;
}
$row = $res->fetch_assoc();
if(password_verify($senha, $row['senha'])){
  // remove senha antes de armazenar/retornar
  unset($row['senha']);
  $_SESSION['user'] = $row;
  echo json_encode(['success'=>true,'message'=>'Login ok.']);
} else {
  echo json_encode(['success'=>false,'message'=>'Senha incorreta.']);
}
$stmt->close();
$conn->close();
?>