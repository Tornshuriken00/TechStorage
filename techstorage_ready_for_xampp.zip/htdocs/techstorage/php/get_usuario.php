<?php
header('Content-Type: application/json; charset=utf-8');
session_start();
if(!isset($_SESSION['user'])){
  echo json_encode(['success'=>false,'message'=>'Não autenticado.']);
  exit;
}
// garante que só campos públicos sejam retornados
$user = $_SESSION['user'];
echo json_encode(['success'=>true,'user'=>$user]);
?>